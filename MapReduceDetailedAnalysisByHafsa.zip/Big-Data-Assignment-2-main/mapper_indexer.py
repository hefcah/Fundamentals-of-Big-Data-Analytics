#!/usr/bin/env python3

import sys
import re
from collections import Counter
from math import log

def clean_text(text):
    # Remove punctuation and convert to lowercase
    text = re.sub(r'[^\w\s]', '', text.lower())
    return text.split()

# Load IDF values
idf_values = {}  # Assume IDF values are precomputed and loaded into this dictionary

# Input comes from standard input
for line in sys.stdin:
    # Parse input
    article_id, section_text = line.strip().split('\t')

    # Clean text
    words = clean_text(section_text)

    # Compute term frequencies
    tf = Counter(words)

    # Compute TF-IDF weights
    tfidf = {word: tf[word] * idf_values.get(word, 0) for word in tf}

    # Emit document ID and TF-IDF representation
    for word, weight in tfidf.items():
        print(f"{article_id}\t{word}\t{weight}")
