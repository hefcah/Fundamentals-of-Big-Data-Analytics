#!/usr/bin/env python3

import sys

# Input comes from STDIN (standard input)
for line in sys.stdin:
    # Remove leading and trailing whitespace
    line = line.strip()
    # Split the line into words
    words = line.split()
    # Emit key-value pairs for each word
    for word in words:
        # Output tab-delimited key-value pairs
        print(f"{word.lower()}\t1")

