#!/usr/bin/env python3

import sys

# Initialize variables
current_word = None
current_count = 0

# Input comes from standard input
for line in sys.stdin:
    # Remove leading and trailing whitespace
    line = line.strip()

    # Split the line into word and count
    word, count = line.split("\t", 1)

    # Convert count to integer
    count = int(count)

    # If the word is the same as the current word, increment count
    if word == current_word:
        current_count += count
    else:
        # If the word is different, output the current word and total count
        if current_word:
            print(f"{current_word}\t{current_count}")
        # Reset variables for new word
        current_word = word
        current_count = count

# Output the last word if needed
if current_word:
    print(f"{current_word}\t{current_count}")

