import random
import time
from collections import defaultdict
from itertools import combinations
from producer import generate_data  

def pcy(data_stream, min_support=2):
    """PCY (Park, Chen, Yu) algorithm for frequent itemset mining."""
    itemset_counts = defaultdict(int)
    bucket_counts = defaultdict(int)
    bucket_size = 10  

    for transaction in data_stream:
        items = transaction["items"]
        subsets = [frozenset(combo) for size in range(1, len(items)+1) for combo in combinations(items, size)]

        for item in items:
            bucket_index = hash(item) % bucket_size
            bucket_counts[bucket_index] += 1

        for subset in subsets:
            if all(hash(item) % bucket_size == 0 for item in subset):
                itemset_counts[subset] += 1

        frequent_itemsets = [itemset for itemset, count in itemset_counts.items() if count >= min_support]
        yield frequent_itemsets

def consumer_pcy():
    """Consumer function that applies PCY algorithm on streaming data."""
    data_stream = generate_data()  
    min_support = 2

    print("Applying PCY algorithm to identify frequent itemsets...")

    for frequent_itemsets in pcy(data_stream, min_support):
        if frequent_itemsets:
            print("Frequent Itemsets:")
            for itemset in frequent_itemsets:
                print(itemset)
            break  

if _name_ == "_main_":
    consumer_pcy()
