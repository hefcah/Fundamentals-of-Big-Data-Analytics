#!/usr/bin/env python3

import sys

def reducer():
    # Read input from standard input
    for line in sys.stdin:
        # Remove leading and trailing whitespace
        line = line.strip()
        
        # Split the line into document ID and tuple containing relevance score and content
        doc_id, relevance_score_content = line.split("\t", 1)
        
        # Parse the tuple to extract relevance score and content
        relevance_score, content = eval(relevance_score_content)
        
        # Output relevant content along with relevance score
        print(f"Relevance Score: {relevance_score}")
        print(content)
        print()

if __name__ == "__main__":
    reducer()
