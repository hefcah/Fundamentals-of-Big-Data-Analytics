#!/usr/bin/env python3

import sys

def mapper():
    # Read input from standard input
    for line in sys.stdin:
        # Remove leading and trailing whitespace
        line = line.strip()
        
        # Split the line into document ID, relevance score, and content
        doc_id, relevance_score, content = line.split("\t", 2)
        
        # Emit document ID and tuple containing relevance score and content
        print(f"{doc_id}\t({relevance_score}, {content})")

if __name__ == "__main__":
    mapper()
