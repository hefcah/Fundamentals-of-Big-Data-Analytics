from collections import defaultdict
from itertools import combinations
import random
import time

def generate_data():
    """Generator function to simulate data stream from producer."""
    data = [
        {"transaction_id": 1, "items": ["item1", "item2", "item3", "item4", "item5"]},
        {"transaction_id": 2, "items": ["item3", "item6", "item7", "item8", "item9"]},
        {"transaction_id": 3, "items": ["item1", "item4", "item8", "item9", "item10"]},
    ]

    while True:
        transaction = random.choice(data)
        yield transaction
        time.sleep(1)  

def apriori(data_stream, min_support=2):
    """Apriori algorithm for frequent itemset mining."""
    itemset_counts = defaultdict(int)

    for transaction in data_stream:
        items = transaction["items"]
        print(f"Processing transaction {transaction['transaction_id']}: {items}")  # Debug statement
        subsets = [frozenset(combo) for size in range(1, len(items)+1) for combo in combinations(items, size)]
        for subset in subsets:
            itemset_counts[subset] += 1

    frequent_itemsets = [itemset for itemset, count in itemset_counts.items() if count >= min_support]
    return frequent_itemsets

def consumer_apriori():
    """Consumer function that applies Apriori algorithm on streaming data."""
    data_stream = generate_data()
    min_support = 2

    print("Applying Apriori algorithm to identify frequent itemsets...")

    frequent_itemsets = apriori(data_stream, min_support)

    print("Frequent Itemsets:")
    for itemset in frequent_itemsets:
        print(itemset)

if _name_ == "_main_":
    consumer_apriori()
