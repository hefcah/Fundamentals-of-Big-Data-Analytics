#!/usr/bin/env python3

import sys

def mapper():
    # Read input from standard input
    for line in sys.stdin:
        # Remove leading and trailing whitespace
        line = line.strip()
        
        # Tokenize the line into individual terms
        terms = line.split()
        
        # Emit key-value pairs for each term in the query
        for term in terms:
            # Emit term and count of 1
            print(f"{term}\t1")

if __name__ == "__main__":
    mapper()
