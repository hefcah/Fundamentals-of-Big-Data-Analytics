#!/usr/bin/env python3

import sys

def mapper():
    # Read query vector from distributed cache or input stream
    query_vector = {}  # Assuming the query vector is already available
    
    # Read document vectors from standard input
    for line in sys.stdin:
        # Remove leading and trailing whitespace
        line = line.strip()
        
        # Split the line into document ID and vector representation
        doc_id, vector = line.split("\t", 1)
        
        # Parse the vector representation
        doc_vector = {}
        for pair in vector.split(","):
            term, tfidf = pair.split(":")
            doc_vector[term] = float(tfidf)
        
        # Calculate relevance score for the document
        relevance = calculate_relevance(query_vector, doc_vector)
        
        # Emit document ID and relevance score
        print(f"{doc_id}\t{relevance}")

def calculate_relevance(query_vector, doc_vector):
    # Implement relevance calculation (e.g., dot product)
    relevance = 0
    for term in query_vector:
        if term in doc_vector:
            relevance += query_vector[term] * doc_vector[term]
    return relevance

if __name__ == "__main__":
    mapper()
