#!/usr/bin/env python3

import sys
from collections import defaultdict

current_doc_id = None
tfidf_dict = defaultdict(float)

# Input comes from standard input
for line in sys.stdin:
    # Parse input
    doc_id, word, tfidf = line.strip().split('\t')
    
    # Convert tfidf to float
    tfidf = float(tfidf)

    # If the document ID changes, emit the current document ID and its TF-IDF representation
    if doc_id != current_doc_id:
        if current_doc_id:
            tfidf_str = '\t'.join(f"{word}:{weight}" for word, weight in tfidf_dict.items())
            print(f"{current_doc_id}\t{tfidf_str}")
        current_doc_id = doc_id
        tfidf_dict = defaultdict(float)

    # Accumulate TF-IDF values for each document
    tfidf_dict[word] += tfidf

# Output the last document's TF-IDF representation
if current_doc_id:
    tfidf_str = '\t'.join(f"{word}:{weight}" for word, weight in tfidf_dict.items())
    print(f"{current_doc_id}\t{tfidf_str}")
