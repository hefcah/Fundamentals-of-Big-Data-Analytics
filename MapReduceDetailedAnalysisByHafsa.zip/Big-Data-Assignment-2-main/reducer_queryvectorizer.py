#!/usr/bin/env python3

import sys

def reducer():
    # Initialize variables
    query_terms = {}
    
    # Read input from standard input
    for line in sys.stdin:
        # Remove leading and trailing whitespace
        line = line.strip()
        
        # Split the line into term and count
        term, count = line.split("\t")
        
        # Convert count to integer
        count = int(count)
        
        # Aggregate counts for each term
        if term in query_terms:
            query_terms[term] += count
        else:
            query_terms[term] = count
    
    # Output the vector representation of the query
    for term, count in query_terms.items():
        print(f"{term}\t{count}")

if __name__ == "__main__":
    reducer()
