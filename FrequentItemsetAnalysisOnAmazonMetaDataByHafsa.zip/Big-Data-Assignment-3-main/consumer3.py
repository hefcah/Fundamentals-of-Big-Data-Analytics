from producer import generate_data  
import time

def frequent_pattern_growth(data_stream):
    """Apply frequent pattern growth algorithm on streaming data."""
    print("Applying frequent pattern growth algorithm...")

    for transaction in data_stream:
        print("Processing transaction:", transaction)
        time.sleep(1)  

def consumer_fpgrowth():
    """Consumer function that processes data using frequent pattern growth."""
    data_stream = generate_data()  

    frequent_pattern_growth(data_stream)

if _name_ == "_main_":
    consumer_fpgrowth()
