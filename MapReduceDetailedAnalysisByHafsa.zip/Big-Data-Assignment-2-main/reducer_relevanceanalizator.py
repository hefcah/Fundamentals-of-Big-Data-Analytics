#!/usr/bin/env python3

import sys

def reducer():
    # Initialize variables
    document_scores = []
    
    # Read input from standard input
    for line in sys.stdin:
        # Remove leading and trailing whitespace
        line = line.strip()
        
        # Split the line into document ID and relevance score
        doc_id, relevance = line.split("\t")
        
        # Convert relevance score to float
        relevance = float(relevance)
        
        # Append document ID and relevance score to the list
        document_scores.append((doc_id, relevance))
    
    # Sort the list of document scores based on relevance score
    document_scores.sort(key=lambda x: x[1], reverse=True)
    
    # Output the sorted list of documents with relevance scores
    for doc_id, relevance in document_scores:
        print(f"{doc_id}\t{relevance}")

if __name__ == "__main__":
    reducer()
