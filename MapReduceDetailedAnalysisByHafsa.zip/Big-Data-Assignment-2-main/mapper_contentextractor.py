#!/usr/bin/env python3

import sys

def mapper():
    # Read relevant document IDs from distributed cache or input stream
    relevant_doc_ids = set()  # Assuming the relevant document IDs are already available
    
    # Read the entire text corpus from standard input
    for line in sys.stdin:
        # Remove leading and trailing whitespace
        line = line.strip()
        
        # Split the line into document ID and content
        doc_id, content = line.split("\t", 1)
        
        # Check if the document ID is in the set of relevant document IDs
        if doc_id in relevant_doc_ids:
            # Emit document ID and content
            print(f"{doc_id}\t{content}")

if __name__ == "__main__":
    mapper()

