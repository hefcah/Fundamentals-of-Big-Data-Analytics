#!/usr/bin/env python3

import sys

# Initialize variables
current_word = None
current_count = 0

# Input comes from standard input
for line in sys.stdin:
    # Remove leading and trailing whitespace
    line = line.strip()

    # Split the line into words
    words = line.split()

    # Process each word
    for word in words:
        # Check if word is not empty
        if word:
            # If the word is the same as the current word, increment count
            if word == current_word:
                current_count += 1
            else:
                # If the word is different, output the current word and count
                if current_word:
                    print(f"{current_word}\t{current_count}")
                # Reset variables for new word
                current_word = word
                current_count = 1

# Output the last word if needed
if current_word:
    print(f"{current_word}\t{current_count}")

