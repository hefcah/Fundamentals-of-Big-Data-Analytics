import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from scipy.sparse import lil_matrix
import numpy as np  # Added import for numpy

# Load data from cleaned CSV with only 'artist_name' and 'track_id' columns
songs = pd.read_csv('mapper.csv', usecols=['artist_name', 'track_id'])

# Define batch size
outer_batch_size = 1000
num_batches = len(songs) // outer_batch_size


class ContentBasedRecommender:
    def __init__(self, data, inner_batch_size):
        self.data = data
        self.inner_batch_size = inner_batch_size
        self.tfidf = TfidfVectorizer(analyzer='word', stop_words='english')
        self.cosine_similarities = None

    def process_batches(self):
        # Initialize cosine similarities matrix as lil_matrix
        num_samples = len(self.data)
        self.cosine_similarities = lil_matrix((num_samples, num_samples))

        # Process data in batches
        for i in range(num_batches):
            start_idx = i * self.inner_batch_size
            end_idx = (i + 1) * self.inner_batch_size if i < num_batches - 1 else num_samples

            # Extract batch
            batch_data = self.data.iloc[start_idx:end_idx]

            # Compute TF-IDF for batch
            lyrics_matrix = self.tfidf.fit_transform(batch_data['artist_name'])

            # Compute cosine similarities for batch
            cosine_similarities_batch = cosine_similarity(lyrics_matrix)

            # Update cosine similarities matrix with batch results
            self.cosine_similarities[start_idx:end_idx, start_idx:end_idx] = cosine_similarities_batch

        # Convert lil_matrix to csr_matrix for efficiency in subsequent operations
        self.cosine_similarities = self.cosine_similarities.tocsr()

    def recommend_all_artists(self, number_songs_per_artist):
        unique_artists = self.data['artist_name'].unique()
        for artist_name in unique_artists:
            print(f"Recommendations for {artist_name}:")
            self.recommend(artist_name, number_songs_per_artist)
            print()

    def recommend(self, artist_name, number_songs):
        # Find the indices of songs by the artist
        indices = self.data[self.data['artist_name'] == artist_name].index

        if self.cosine_similarities is None:
            self.process_batches()

        # Initialize recommended songs list
        recom_song_list = []
        for idx in indices:
            # Convert the row of cosine similarities matrix to dense array
            cosine_similarities_row = self.cosine_similarities[idx].toarray().flatten()

            # Get the indices that would sort the cosine similarities
            similar_indices = np.argsort(cosine_similarities_row)[::-1][:number_songs]

            # Get recommendations
            recom_song = [
                (cosine_similarities_row[x], self.data['track_id'].iloc[x], self.data['artist_name'].iloc[x]) for x
                in similar_indices]
            recom_song_list.extend(recom_song[1:])  # Exclude the first (same song)

        # Print recommendations
        self._print_message(artist_name, recom_song_list)

    @staticmethod
    def _print_message(artist_name, recom_song):
        rec_items = len(recom_song)
        print(f'The {rec_items} recommended songs for {artist_name} are:')
        for i in range(rec_items):
            print(f"Number {i + 1}:")
            print(
                f"Track ID: {recom_song[i][1]} by {recom_song[i][2]} with {round(recom_song[i][0], 3)} similarity score")
            print("--------------------")


# Initialize recommender with song data and batch size
recommender = ContentBasedRecommender(songs, outer_batch_size)

# Example usage:
number_recommendations_per_artist = 4
recommender.recommend_all_artists(number_recommendations_per_artist)
