import os
import librosa
from librosa import feature
from pymongo import MongoClient
from sklearn.preprocessing import StandardScaler
import numpy as np
import gc

client = MongoClient('localhost', 27017)
db = client['audio_features']
collection = db['audio_data']


def extract_features(audio_path):
    try:
        y, sr = librosa.load(audio_path)
        mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
        mfcc_mean = mfcc.mean(axis=1)
        spectral_centroid = librosa.feature.spectral_centroid(y=y, sr=sr)
        spectral_centroid_mean = spectral_centroid.mean()
        zero_crossing_rate = librosa.feature.zero_crossing_rate(y)
        zero_crossing_rate_mean = zero_crossing_rate.mean()
        features = {
            'mfcc': mfcc_mean.tolist(),
            'spectral_centroid': spectral_centroid_mean.item(),
            'zero_crossing_rate': zero_crossing_rate_mean.item()
        }
        return features
    except Exception as e:
        print(f"Error extracting features from {audio_path}: {e}")
        return None


def process_audio_directory_batched(directory, batch_size=10):
    batch_count = 0
    for root, dirs, files in os.walk(directory):
        for filename in files:
            if filename.endswith('.mp3'):
                audio_path = os.path.join(root, filename)
                features = extract_features(audio_path)
                if features:
                    track_id = int(filename.split('.')[0])  # Extract track ID
                    try:
                        collection.insert_one({'filename': filename, 'track_id': track_id, 'features': features})
                    except Exception as e:
                        print(f"Error storing features for {filename}: {e}")
                batch_count += 1
                if batch_count >= batch_size:
                    batch_count = 0
                    gc.collect()


def normalize_features():
    scaler = StandardScaler()
    features_list = [doc['features'] for doc in collection.find()]
    if not features_list:
        print("No features found in the MongoDB collection.")
        return
    features_array = np.array(features_list)
    normalized_features = scaler.fit_transform(features_array)
    for idx, doc in enumerate(collection.find()):
        collection.update_one({'_id': doc['_id']}, {'$set': {'normalized_features': normalized_features[idx].tolist()}})


audio_directory = r'E:\Study\BDA\sample'
process_audio_directory_batched(audio_directory)
normalize_features()
