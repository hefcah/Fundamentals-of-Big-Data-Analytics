import pandas as pd
from pymongo import MongoClient

# Connect to the new MongoDB database
client_new = MongoClient('localhost', 27017)
db_new = client_new['new_audio_features']
collection_new = db_new['song_data']

# Read the CSV file into a DataFrame
csv_file = r'E:\raw_tracks.csv'  # Replace 'your_file_name.csv' with the actual name of your CSV file
df = pd.read_csv(csv_file)

# Extract features and store in the new MongoDB database
for _, row in df.iterrows():
    # Extracting genre titles from track_genres
    genres_list = []
    track_genres = row['track_genres']
    if isinstance(track_genres, str):
        genres_data = eval(track_genres)  # Assuming 'track_genres' is a string representation of a list of dictionaries
        for genre_data in genres_data:
            genre_title = genre_data.get('genre_title')
            if genre_title:
                genres_list.append(genre_title)

    features = {
        'track_id': row['track_id'],
        'artist_name': row['artist_name'],
        'track_genres': genres_list  # Storing only the genre titles
    }
    try:
        collection_new.insert_one(features)
    except Exception as e:
        print(f"Error storing features: {e}")
