#!/usr/bin/env python3

import sys

def reducer():
    # Read input from standard input
    for line in sys.stdin:
        # Remove leading and trailing whitespace
        line = line.strip()
        
        # Split the line into document ID and content
        doc_id, content = line.split("\t", 1)
        
        # Output the relevant content
        print(content)

if __name__ == "__main__":
    reducer()
