import sqlite3
import random
from collections import defaultdict

conn = sqlite3.connect('fpgrowth_results.db')
cursor = conn.cursor()

def calculate_frequent_itemsets(items, min_support):
    item_counts = defaultdict(int)
    for item in items:
        item_counts[item] += 1
    
    total_transactions = len(items)
    frequent_itemsets = {}
    for item, count in item_counts.items():
        support = count / total_transactions
        if support >= min_support:
            frequent_itemsets[frozenset([item])] = support
    
    return frequent_itemsets

def frequent_pattern_growth(data_stream, min_support):
    cursor.execute('CREATE TABLE IF NOT EXISTS fpgrowth_results (itemset TEXT, support REAL)')
    try:
        for transaction in data_stream:
            items = transaction['items']
            frequent_itemsets = calculate_frequent_itemsets(items, min_support)

            for itemset, support in frequent_itemsets.items():
                cursor.execute('INSERT INTO fpgrowth_results (itemset, support) VALUES (?, ?)', (str(itemset), support))
                conn.commit()

            print(f"Frequent itemsets processed for transaction: {items}")

    except Exception as e:
        print(f"Error occurred: {e}")

def generate_data():
    """Generate synthetic transaction data."""
    try:
        while True:
            transaction = {
                'items': random.choices(['item1', 'item2', 'item3', 'item4', 'item5'], k=random.randint(1, 5))
            }
            yield transaction

    except Exception as e:
        print(f"Error occurred in data generation: {e}")

def consumer_fpgrowth():
    data_stream = generate_data()
    frequent_pattern_growth(data_stream, min_support=0.5)

if __name__ == '__main__':
    consumer_fpgrowth()

cursor.close()
conn.close()
