import json
import time
import random

def generate_data():
    """Generate synthetic data with specific item names."""
    data = [
        {"transaction_id": 1, "items": ["b00005kjxm", "b000pltlng", "b003qhzarm", "b00kqf4vzy", "b07b7l8c6k"]},
        {"transaction_id": 2, "items": ["b00fb3jje4", "b075vfslf2", "b00km5lsko", "b00wlw1jqe", "b007q9130y"]},
        {"transaction_id": 3, "items": ["b00fb3jje4", "b075vfslf2", "b00km5lsko", "b00wlw1jqe"]},
        
    ]

    while True:
        transaction = random.choice(data)
        yield transaction
        time.sleep(1)  

def producer():
    """Stream synthetic data to consumers."""
    data_stream = generate_data()
    for item in data_stream:
        print(f"Streaming data: {item}")
        time.sleep(1)  

if _name_ == "_main_":
    producer()
