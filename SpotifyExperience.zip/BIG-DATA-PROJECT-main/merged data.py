from pymongo import MongoClient

# Connect to the 'audio_features' MongoDB database
client_audio = MongoClient('localhost', 27017)
db_audio = client_audio['audio_features']
collection_audio = db_audio['audio_data']

# Connect to the 'new_audio_features' MongoDB database
client_new = MongoClient('localhost', 27017)
db_new = client_new['new_audio_features']
collection_new = db_new['song_data']

# Fetch all data from 'audio_features' collection
data_from_audio = list(collection_audio.find())

# Fetch all data from 'new_audio_features' collection
data_from_new = list(collection_new.find())

# Merge and prepare the data
merged_data = {}
for doc1 in data_from_audio:
    track_id = doc1['track_id']
    merged_data[track_id] = {
        'track_id': track_id,
        'artist_name': None,
        'track_genres': None,
        'mfcc': doc1.get('features').get('mfcc'),  # Use get() method to avoid KeyError and get None if key doesn't exist
        'zero_crossing_rate': doc1.get('features').get('zero_crossing_rate'),
        'spectral_centroid': doc1.get('features').get('spectral_centroid')
    }

for doc2 in data_from_new:
    track_id = doc2['track_id']
    if track_id in merged_data:
        if not merged_data[track_id]['artist_name']:
            merged_data[track_id]['artist_name'] = doc2['artist_name']
        if not merged_data[track_id]['track_genres']:
            merged_data[track_id]['track_genres'] = doc2['track_genres']
    else:
        merged_data[track_id] = {
            'track_id': track_id,
            'artist_name': doc2['artist_name'],
            'track_genres': doc2['track_genres'],
            'mfcc': None,
            'zero_crossing_rate': None,
            'spectral_centroid': None
        }

# Connect to the new database for storing merged data
client_merged = MongoClient('localhost', 27017)
db_merged = client_merged['merged_database']
merged_collection = db_merged['merged_data']

# Insert the merged data into the new collection in the new database
if merged_data:
    merged_collection.insert_many(list(merged_data.values()))
    print(f"Merged and stored {len(merged_data)} documents in the 'merged_data' collection in the new database.")
else:
    print("No data to merge and store.")
